function checkNumber(){
        let num = prompt("Enter a Number");
        if(num>0){
            document.getElementById('num').innerHTML = "Number is positive..."
        }
        else if (num = 0){
             document.getElementById('num').innerHTML = "Numbere is Zero..."
        }
        else {
             document.getElementById('num').innerHTML = ""
        }
     }
  