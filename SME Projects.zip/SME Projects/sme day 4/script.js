// Student Portal - interactive front-end demo
(() => {
  const initialStudents = [
    {id:1,name:'Aditi Sharma',course:'B.Tech CSE',email:'aditi@stu.com',gender:'Female',phone:'9876543210',dob:'2005-03-12',status:'Active'},
    {id:2,name:'Rohan Mehta',course:'B.Tech ECE',email:'rohan@stu.com',gender:'Male',phone:'9876543211',dob:'2004-11-24',status:'Active'},
    {id:3,name:'Sneha Patel',course:'B.Sc CS',email:'sneha@stu.com',gender:'Female',phone:'9876543212',dob:'2005-06-08',status:'Active'},
    {id:4,name:'Arjun Singh',course:'B.Tech CSE',email:'arjun@stu.com',gender:'Male',phone:'9876543213',dob:'2004-09-19',status:'Active'},
    {id:5,name:'Kabir Verma',course:'BBA',email:'kabir@stu.com',gender:'Male',phone:'9876543214',dob:'2005-01-30',status:'Active'}
  ];
  let students = [...initialStudents];
  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const titles = {dashboard:'Student Dashboard',add:'Add New Student',students:'All Students',search:'Search Student',delete:'Delete Student'};

  function escapeHtml(value) {
    return String(value ?? '').replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  }
  function toast(message) {
    const el = $('#toast');
    if (!el) return;
    el.textContent = message;
    el.classList.add('show');
    clearTimeout(toast.timer);
    toast.timer = setTimeout(() => el.classList.remove('show'), 2500);
  }
  function navigate(view) {
    if (!titles[view] || !$('#' + view + 'View')) return;
    $$('.view').forEach(el => el.classList.remove('active-view'));
    $('#' + view + 'View').classList.add('active-view');
    $$('.nav-link').forEach(btn => btn.classList.toggle('active', btn.dataset.view === view));
    $('#pageTitle').textContent = titles[view];
    $('#sidebar').classList.remove('open');
    renderAll();
    window.scrollTo({top:0, behavior:'smooth'});
  }
  function rows(items, withActions = false) {
    const colspan = withActions ? 7 : 5;
    if (!items.length) return `<tr><td colspan="${colspan}">No student records found.</td></tr>`;
    return items.map(s => `<tr><td class="id-cell">#${s.id}</td><td><strong>${escapeHtml(s.name)}</strong></td><td>${escapeHtml(s.course)}</td><td>${escapeHtml(s.email)}</td>${withActions ? `<td>${escapeHtml(s.gender)}</td>` : ''}<td><span class="status-pill">${escapeHtml(s.status)}</span></td>${withActions ? `<td><button type="button" class="table-action delete-btn" data-delete="${s.id}">Delete</button></td>` : ''}</tr>`).join('');
  }
  function renderAll() {
    $('#totalCount').textContent = students.length;
    $('#activeCount').textContent = students.filter(s => s.status === 'Active').length;
    $('#maleCount').textContent = students.filter(s => s.gender === 'Male').length;
    $('#femaleCount').textContent = students.filter(s => s.gender === 'Female').length;
    $('#recentTable').innerHTML = rows([...students].slice(-5).reverse());
    const filter = ($('#studentFilter')?.value || '').trim().toLowerCase();
    $('#studentsTable').innerHTML = rows(students.filter(s => `${s.name} ${s.course} ${s.email}`.toLowerCase().includes(filter)), true);
    $('#deleteTable').innerHTML = students.length ? students.map(s => `<tr><td>#${s.id}</td><td><strong>${escapeHtml(s.name)}</strong></td><td>${escapeHtml(s.course)}</td><td>${escapeHtml(s.email)}</td><td><button type="button" class="table-action delete-btn" data-delete="${s.id}">Delete</button></td></tr>`).join('') : '<tr><td colspan="5">No student records found.</td></tr>';
  }

  // Delegated clicks keep navigation and dynamically rendered action buttons working.
  document.addEventListener('click', event => {
    const nav = event.target.closest('[data-view]');
    if (nav) { navigate(nav.dataset.view); return; }
    const go = event.target.closest('[data-go]');
    if (go) { navigate(go.dataset.go); return; }
    if (event.target.closest('#menuToggle')) { $('#sidebar').classList.toggle('open'); return; }
    const del = event.target.closest('[data-delete]');
    if (del) {
      const student = students.find(s => s.id === Number(del.dataset.delete));
      if (student && window.confirm(`Delete ${student.name}'s record?`)) {
        students = students.filter(s => s.id !== student.id);
        renderAll(); toast('Student record deleted.');
      }
    }
  });

  $('#studentForm').addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const email = String(data.get('email') || '').trim().toLowerCase();
    if (students.some(s => s.email.toLowerCase() === email)) { toast('A student with this email already exists.'); return; }
    students.push({id: students.length ? Math.max(...students.map(s => s.id)) + 1 : 1,
      name:String(data.get('name') || '').trim(), phone:String(data.get('phone') || '').trim(), email,
      gender:String(data.get('gender') || ''), course:String(data.get('course') || ''), dob:String(data.get('dob') || ''), status:'Active'});
    event.currentTarget.reset(); renderAll(); toast('Student added successfully!'); navigate('students');
  });
  $('#studentFilter').addEventListener('input', renderAll);
  $('#searchForm').addEventListener('submit', event => {
    event.preventDefault();
    const q = $('#searchInput').value.trim().toLowerCase();
    const results = $('#searchResults');
    if (!q) { results.innerHTML = '<div class="empty-state">Please enter a name or email address.</div>'; return; }
    const found = students.filter(s => s.name.toLowerCase().includes(q) || s.email.toLowerCase().includes(q));
    results.innerHTML = found.length ? found.map(s => `<article class="student-result"><div class="avatar-large">${escapeHtml(s.name.charAt(0).toUpperCase())}</div><div class="result-details"><div><strong>Name:</strong><span>${escapeHtml(s.name)}</span></div><div><strong>Email:</strong><span>${escapeHtml(s.email)}</span></div><div><strong>Course:</strong><span>${escapeHtml(s.course)}</span></div><div><strong>Gender:</strong><span>${escapeHtml(s.gender)}</span></div><div><strong>Phone:</strong><span>${escapeHtml(s.phone || '—')}</span></div><div><strong>Status:</strong><span>${escapeHtml(s.status)}</span></div></div></article>`).join('') : `<div class="empty-state">No students match “${escapeHtml(q)}”. Try another search.</div>`;
  });
  renderAll();
})();
