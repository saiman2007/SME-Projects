function factorial(){
    let num = prompt("Enter a Number..");
  let fact= 1;
    for( i= 1; i<=num; i++ ){
      fact = fact*i;
    }
    document.getElementById('demo').innerHTML = "factorial = " + fact;
}