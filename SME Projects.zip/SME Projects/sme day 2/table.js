function Table(){
    let num = prompt("Enter a Number");
    let text = "";
    for(let i = 1; i<=10; i++){
        text += num + " * " +i +" = " + (num*i) + "<br>";
    }
    document.getElementById('num').innerHTML=text;
}