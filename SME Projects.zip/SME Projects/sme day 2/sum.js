function sum(){
    let num = 100;
    let sum = 0;
    for (let i = 0; i<=100; i++){
    sum = sum+i;
    }
    document.getElementById('num').innerHTML="Sum Of First 100 No's: " + sum;
}