function operator(){
    let oper = '+';
    let x=20,y=10;
    switch(oper){
        case '+': x+y;
        break;
        case '-':
            x-y;
            break;
            case '/':
                x/y;
                break;
                case '*':
                    x*y;
                    document.getElementById('demo').innerHTML=oper;

    }
}