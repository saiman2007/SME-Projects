function numberFinder(){
    let num = prompt("Enter a Number");
    if (num % 2 ){
        document.getElementById('check').innerHTML="Number is even";
    }
    else{
        document.getElementById('check').innerHTML= "Number is Odd"
    }
}