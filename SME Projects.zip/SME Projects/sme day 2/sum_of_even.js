function even(){
    let sum = 0;
    for( let i=0; i<=50; i++){
        if(i%2 ==0){
            sum= sum+i;
        }
    }
document.getElementById('demo').innerHTML= "Sum OF even No's From 1 to 50 = " + sum;
}