function studentDetail(){
let name = prompt("Enter Your name");
let rollNo = prompt("Enter Your Roll No.");
let subject1 =Number(prompt("Enter Marks of Math"));
let subject2 =Number( prompt("Enter Marks of front-end"));
let subject3 = Number(prompt("Enter Marks of English"));
let subject4 = Number( prompt("Enter Marks of COA"));
let subject5 = Number(prompt("Enter Marks of AI"));
let total_marks = subject1 + subject2 + subject3 + subject4 + subject5;

let percentage = total_marks / 5 ;
let display1 = "Name of Student :- " + name;

let display2 = " Roll No :- " + rollNo ;
let display3 =" Total Marks:- " + total_marks ;
let display4 = " Percentage is:- " + percentage;

document.getElementById('demo').innerHTML = 
                            "<h2> Student Details </h2>" +
                            display1 + "<br>" + 
                            display2 +"<br>" +
                            display3 + "<br>" +
                            display4;
                                             
}















