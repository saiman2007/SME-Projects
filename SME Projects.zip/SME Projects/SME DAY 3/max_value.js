function maxArray(){
    let arr =[10 , 90, 50, 80, 54];
    let max = arr[0];
    for( let i = 1; i<arr.length; i++){
        if(arr[i] > max){
        max = arr[i];
    }
}
    console.log("Maximum Value Of Array is :- " + max);
}