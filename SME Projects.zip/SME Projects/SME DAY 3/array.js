function array(){
    const cars = [];
   cars[0] = "BMW";
   cars[1] = "audi";
   cars[2] = "mercedes";
   cars[3] = "buggati";
   cars[4] = "ferrari";
    for(let i = 0; i<cars.length; i++) {
        console.log(cars[i]);
    }
}
