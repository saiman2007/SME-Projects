function evenArray(){
         let arr = [];
         for(let i = 0; i<=50; i++ ){
            arr.push(i);
         }
         for(let i = 0; i<arr.length; i++){
            if(arr[i] % 2 == 0){
            console.log(arr[i]);
            }
         }
         


}