function validation(){
    let name= document.forms["myform"]["sname"].value;
    let rollno = document.forms["myform"]["srollno"].value;
    let password = document.forms["myform"]["spassword"].value;
    let confirm = document.forms["myform"]["sconfirm"].value;
    let email = document.forms["myform"]["semail"].value;
    const pattern = /^[^\s@]+@[^\s@]+\.[^s@]+$/;
    if(name =="" && rollno=="" && email == "" && Passord =="" && confirm == "" ){
        alert("Please fill the form");
    }
    else if (name.length<3){
        alert("please fill the full name");
        return false;
    }
    
    
    else if( password.length<8)

{
    alert("Passoword must contain at least 8 character ");
    return false;
}
else if(password != confirm){
    alert("Password do not match");
    return false;
}
else if(!pattern.test(email)){
    alert("please enter a valid email adress");
    return false;
}
else {
    alert("Signup Successfull");
    return true;
}
    
    
}