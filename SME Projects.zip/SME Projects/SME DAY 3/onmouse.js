function func1(){
    document.getElementById("para").style.color ="red";
}
function func2(){
    document.getElementById("para").style.color ="blue";
}
function modifyText(){
    const namefield=document.getElementById("name");
    namefield.value=namefield.value.toUpperCase();
}