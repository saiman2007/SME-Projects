function persona(){
const person = {
    firstName: "john",
    lastName: "doe",
    age: 50,
    fullName: function(){
        return this.firstName + " " + this.lastName;
    }
};




       console.log(person.firstName);
       console.log(person.age);
       console.log(person.fullName());
    }
    

